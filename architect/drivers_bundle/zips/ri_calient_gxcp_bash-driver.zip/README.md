# Calient GXCP + bash shell (community)

Spirent’s stock **`ri_calient`** driver assumes either:

- SSH lands directly on the TL1 `agent>` prompt (e.g. `tl1user`), or  
- `type tl1` prints a shell alias so the driver can enable SSH local forwarding and open TL1 via telnet.

On **Calient-Ocs (GXCP, Linux 2.6.32)** with **`root` + passwordless SSH**, there is **no** `tl1` alias (`type tl1` fails). The stock driver then tries TL1 on the SSH session and **never** reaches the real TL1 agent, so **port discovery returns nothing**.

## What this variant does

Fork of `Drivers/TestedBySpirent/ri_calient/calient.fftc` with:

1. **`type tl1` replaced** by an `echo` that prints the **same shape** of line the driver’s regex expects (`tl… telnet 127.0.0.1 3083`), forcing the **SSH port-forward + telnet to local TL1** path (same as when a real `tl1` alias exists).
2. **Regex relaxed** so the **port** field matches **without** a trailing `'` on the echoed line (matches real `echo` output).
3. **SSH password** bound to **`[param property_password]`** in **both** SSH `Open` steps (session `s1` and forwarded `sPF`) so Velocity’s inventory **`password`** field is applied (works for blank or non-empty SSH passwords).

Other behavior (RTRV-PORT-SUM, ACT-USER, sessions `s1` / `sPF` / `tn1`) is unchanged from the upstream test case.

### Troubleshooting Velocity / iTest driver editor

If the **SSH Session → Password** field looks **blank** after opening the FFTC from the catalog: type **`[param property_password]`** literally (masked fields may look empty but must keep that substitution). Without it SSH never sends the chassis password even if inventory credentials are correct.

## Resource properties (unchanged semantics)

| Property | Notes |
|----------|--------|
| `username` / `password` | SSH — e.g. **`root`**; **leave password blank only** if chassis allows passwordless SSH, otherwise set the real SSH secret (stored in Velocity as `password`; driver maps it via **`property_password`**). |
| `calientUsername` / `calientPassword` | TL1 **after** telnet to `127.0.0.1:3083` — must match a **provisioned TL1 user** (often `admin` + chassis TL1 password, not the same as SSH). |
| `ipAddress` or `Hostname` | Management reachability from Velocity. |

## Package layout

Import **`ri_calient_gxcp_bash-driver.zip`** from `Drivers/Community/` (rebuilt with **flat** zip paths: `manifest.xml` at the **root** of the archive, not under a subfolder).

**Do not** reuse **`metadata.xml`** from stock `ri_calient` with `driverId` / `driverPackageId` — those Spirent UUIDs are not assets on your Velocity server and upload fails with *“Specified asset ID does not refer to an existing asset”*. This package ships metadata **without** those IDs so Velocity can assign new ones.

**Do not push** to GitHub unless you intend to contribute upstream.

## Upstream reference

- Stock driver: `Drivers/TestedBySpirent/ri_calient/`
- Cobalt lab notes: repo `docs/LABVAULT_VS_VELOCITY_OCS.md`
