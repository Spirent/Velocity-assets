Project: Arista EOS L2 Driver (ri_arista)
Description: SSH/iTest Layer 2 switch driver for Arista EOS. Provides VLAN lifecycle,
  port discovery, LLDP neighbors, and system property discovery for Velocity reservations.
Category: driver
Class: Community
Tags: L2, Arista, EOS

Required resource properties:
  username, password
  ipAddress and/or Hostname (at least one required)

Optional resource properties:
  SSH Port (default 22)
  failIfSonicDetected (default true) — when the switch is booted into SONiC, the driver
    returns an error directing you to rp_sonic.l2.switch.driver instead of EOS commands.

Standard L2 procedures:
  getProperties, getPorts, createVlan, destroyVlan, addToVlan, removeFromVlan

Custom procedures (supportCustomArguments):
  getLldpNeighbors — parse show lldp neighbors into JSON neighbor list

VLAN tagging on addToVlan/removeFromVlan:
  tagged (default) — trunk allowed VLAN add/remove
  untagged or access — switchport access vlan

Notes:
  - EOS creates VLANs on first use; createVlan still provisions name VELOCITY_{id}.
  - destroyVlan checks VLAN membership before deletion.
  - Dual-OS hardware running SONiC must use rp_sonic.l2.switch.driver, not this driver.
