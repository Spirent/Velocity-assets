### Project Information:
Project: Arista EOS L2 Driver (ri_arista)  
Description: SSH/iTest Layer 2 switch driver for Arista EOS. Provides VLAN lifecycle,  
  port discovery, LLDP neighbors, and system property discovery for Velocity reservations.  
Category: driver  
Class: Community  
Tags: L2, Arista, EOS  
  
Required resource properties:  
  username, password  
  ipAddress and/or Hostname (at least one required)  
  
Optional resource properties:  
  SSH Port (default 22)  
  failIfSonicDetected (default true) — when the switch is booted into SONiC, the driver  
    returns an error directing you to rp_sonic.l2.switch.driver instead of EOS commands.  
  
Standard L2 procedures:  
  getProperties, getPorts, createVlan, destroyVlan, addToVlan, removeFromVlan  
  
Custom procedures (supportCustomArguments):  
  getLldpNeighbors — parse show lldp neighbors into JSON neighbor list  
  
VLAN tagging on addToVlan/removeFromVlan:  
  tagged (default) — trunk allowed VLAN add/remove  
  untagged or access — switchport access vlan  
  
Notes:  
  - EOS creates VLANs on first use; createVlan still provisions name VELOCITY_{id}.  
  - destroyVlan checks VLAN membership before deletion.  
  - Dual-OS hardware running SONiC must use rp_sonic.l2.switch.driver, not this driver.  

 ----
1 quickcall library in project
## Quickcall Library: arista_base_qc.fftc
### getInterfaces
### addPortToVlan
<table><tr><th>Argument</th><th>Description</th></tr>
<tr><td>vlanId</td><td>can be a single number, a range delimited by "-" or a set of numbers delimited by ","
e.g.
    900
    900-905
    900,902,905</tr></td>
<tr><td>portName</td><tr></tr>
<tr><td>tagging</td><td>tagged (trunk) or access/untagged</tr></td></table>

### removePortFromVlan
<table><tr><th>Argument</th><th>Description</th></tr>
<tr><td>vlanId</td><td>can be a single number, a range delimited by "-" or a set of numbers delimited by ","
e.g.
    900
    900-905
    900,902,905</tr></td>
<tr><td>portName</td><tr></tr>
<tr><td>tagging</td><td>tagged (trunk) or access/untagged</tr></td></table>

### getSystemInfo
### detectActiveOs
### createVlan
<table><tr><th>Argument</th><th>Description</th></tr>
<tr><td>vlanId</td><tr></tr></table>

### destroyVlan
<table><tr><th>Argument</th><th>Description</th></tr>
<tr><td>vlanId</td><tr></tr></table>

### getLldpNeighbors
1 test case in project
## Test Case File: driver.fftc
### getProperties
```
getProperties returns JSON-formatted properties and port data for Velocity inventory sync.
```

### getPorts
```
getPorts returns JSON-formatted Ethernet port information (excludes Vl/Ma/Lo/Po).
```

### createVlan
### addToVlan
### removeFromVlan
### destroyVlan
### getLldpNeighbors
5 response maps in project
## Response Map File: qcGetInterfaces.ffrm
## Response Map File: show_interfaces_description.ffrm
## Response Map File: show_version.ffrm
## Response Map File: show_hostname.ffrm
## Response Map File: show_lldp_neighbors.ffrm