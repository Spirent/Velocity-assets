f=open("debug.txt","r")
print(f.read())
