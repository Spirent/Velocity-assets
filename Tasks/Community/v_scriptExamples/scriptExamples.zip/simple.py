from datetime import datetime
import sys, getopt

print("[WARNING] The message with warning")
print("[ERROR] The message with warning")

print("[INFO] Current time: "+ str(datetime.now()))

print("Execution issue verified message")

print("Finished: PASSED")