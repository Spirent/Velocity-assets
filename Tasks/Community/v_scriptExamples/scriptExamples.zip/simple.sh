#!/bin/sh

echo "Hello world"

echo "[ERROR] Bash Error"
echo "[CRITICAL] Bash Critical"
echo "[DEBUG] Bash Debug"
echo "[INFO] Bash Info"
echo "[WARNING] Bash Warning"
echo "[verified] Bash OK"

echo "Velocity API: $VELOCITY_PARAM_VELOCITY_API_ROOT"
echo "First argument is: $1"
echo "Finished: PASSED"
